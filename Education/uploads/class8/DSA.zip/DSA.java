import java.util.Scanner;
public class DSA
{
	static int rear=-1;
	static int front=-1;
	static final int max=5;
	static int q[]=new int[max];
	static Scanner obj=new Scanner(System.in);
	static void enqueue()
	{
		if(isFull())
		{
			System.out.println("Can't insert the element...");
			return;
		}
		System.out.println("Enter the number of elements: ");
		int data=obj.nextInt();
		if(isEmpty())
		{
			front=0;
		}
		for(int i=0;i<data;i++)
		{
			System.out.println("Enter the Element "+(i+1)+" :");
			int element=obj.nextInt();
			q[++rear]=element;
			System.out.println("The Element "+element+" enque Sucessful....");
		}
	}
	static void dequeue()
	{
		if(isEmpty())
		{
			System.out.println("can't dequeue!!!!!!!!!!!");
			return;
		}
		System.out.println("The element "+q[front]+" deleted Sucessfully.....");
		if(rear==front)
		{
			rear=front=-1;
		}
		else
		{
			front++;
		}
	}
	static void display()
	{
		if(isEmpty())
		{
			System.out.println("can't dequeue!!!!!!!!!!!");
			return;
		}
		System.out.println("Display Elements are: ");
		for(int i=front;i<=rear;i++)
		{
			System.out.println("->"+q[i]);
		}
	}
	static void peek()
	{
		if(isEmpty())
		{
			System.out.println("Empty Queue!!!!!!!!!!!");
			return;
		}
		int a=q[front];
		System.out.println("Peek element is :"+a);
	}
	static boolean isEmpty()
	{
		return front==-1;
	}
	static boolean isFull()
	{
		return rear==max-1;
	}
	public static void main(String[]args)
	{
		while(true)
		{
		System.out.println("1.Enqueue");
		System.out.println("2.Dequeue");
		System.out.println("3.Display");
		System.out.println("4.Peek");
		System.out.println("5.Exit");
		System.out.println("Enter any Choice: ");
		int choice=obj.nextInt();
		switch(choice)
		{
		case 1:
			enqueue();
			break;
		case 2:
			dequeue();
			break;
		case 3:
			display();
			break;
		case 4:
			peek();
			break;
		case 5:
			System.exit(0);
			break;
		}
	}
		// enqueue();
		// display();
		// dequeue();
		// display();
	}
}